package com.capgemini.onlinemovieticket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinemovieticketApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinemovieticketApplication.class, args);
	}

}
