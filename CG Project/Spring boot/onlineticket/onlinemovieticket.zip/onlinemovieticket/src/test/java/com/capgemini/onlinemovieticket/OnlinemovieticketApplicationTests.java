package com.capgemini.onlinemovieticket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinemovieticketApplicationTests {

	@Test
	void contextLoads() {
	}

}
